(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // ../core/dist/data/terms.json
  var require_terms = __commonJS({
    "../core/dist/data/terms.json"(exports, module) {
      module.exports = [
        {
          id: "closure",
          term: "closure",
          match: ["\u30AF\u30ED\u30FC\u30B8\u30E3", "\u30AF\u30ED\u30FC\u30B8\u30E3\u30FC"],
          short: "\u81EA\u5206\u304C\u4F5C\u3089\u308C\u305F\u5834\u6240\u306E\u5909\u6570\u3092\u899A\u3048\u3066\u3044\u308B\u95A2\u6570\u3002",
          detail: "\u95A2\u6570\u304C\u5B9A\u7FA9\u3055\u308C\u305F\u30B9\u30B3\u30FC\u30D7\u306E\u5909\u6570\u3092\u3001\u5916\u306B\u6301\u3061\u51FA\u3055\u308C\u305F\u5F8C\u3082\u53C2\u7167\u3057\u7D9A\u3051\u308B\u4ED5\u7D44\u307F\u3002\u30AB\u30A6\u30F3\u30BF\u3084\u8A2D\u5B9A\u5024\u3092\u5916\u304B\u3089\u89E6\u308C\u306A\u3044\u5F62\u3067\u6301\u305F\u305B\u308B\u306E\u306B\u4F7F\u3046\u3002",
          example: "const counter = (() => { let n = 0; return () => ++n; })();",
          link: "https://developer.mozilla.org/ja/docs/Web/JavaScript/Closures"
        },
        {
          id: "idempotent",
          term: "idempotent",
          match: ["\u51AA\u7B49", "\u3079\u304D\u7B49", "idempotency"],
          short: "\u4F55\u56DE\u5B9F\u884C\u3057\u3066\u3082\u7D50\u679C\u304C\u540C\u3058\u306B\u306A\u308B\u6027\u8CEA\u3002",
          detail: "\u30EA\u30C8\u30E9\u30A4\u3057\u3066\u3082\u58CA\u308C\u306A\u3044\u306E\u3067\u3001\u901A\u4FE1\u304C\u4E0D\u5B89\u5B9A\u306A API \u3084\u30C7\u30D7\u30ED\u30A4\u51E6\u7406\u3067\u91CD\u8981\u306B\u306A\u308B\u3002DELETE \u306F\u51AA\u7B49\u3001POST \u306F\u666E\u901A\u306F\u51AA\u7B49\u3067\u306A\u3044\u3002"
        },
        {
          id: "race-condition",
          term: "race condition",
          match: ["\u7AF6\u5408\u72B6\u614B", "\u30EC\u30FC\u30B9\u30B3\u30F3\u30C7\u30A3\u30B7\u30E7\u30F3"],
          short: "\u51E6\u7406\u306E\u5B9F\u884C\u9806\u5E8F\u6B21\u7B2C\u3067\u7D50\u679C\u304C\u5909\u308F\u3063\u3066\u3057\u307E\u3046\u30D0\u30B0\u3002",
          detail: "\u8907\u6570\u306E\u51E6\u7406\u304C\u540C\u3058\u30C7\u30FC\u30BF\u3092\u540C\u6642\u306B\u8AAD\u307F\u66F8\u304D\u3059\u308B\u3068\u8D77\u304D\u308B\u3002\u518D\u73FE\u3057\u306B\u304F\u304F\u3001\u30ED\u30B0\u306B\u306F\u6B8B\u308A\u306B\u304F\u3044\u306E\u304C\u5384\u4ECB\u306A\u3068\u3053\u308D\u3002"
        },
        {
          id: "memoization",
          term: "memoization",
          match: ["\u30E1\u30E2\u5316", "memoize", "memo"],
          short: "\u4E00\u5EA6\u8A08\u7B97\u3057\u305F\u7D50\u679C\u3092\u899A\u3048\u3066\u304A\u3044\u3066\u4F7F\u3044\u56DE\u3059\u3053\u3068\u3002",
          detail: "\u540C\u3058\u5165\u529B\u306A\u3089\u540C\u3058\u51FA\u529B\u306B\u306A\u308B\u95A2\u6570\u306B\u3060\u3051\u4F7F\u3048\u308B\u3002\u901F\u304F\u306A\u308B\u4EE3\u308F\u308A\u306B\u30E1\u30E2\u30EA\u3092\u98DF\u3046\u306E\u3067\u3001\u91CD\u3044\u8A08\u7B97\u306B\u9650\u5B9A\u3059\u308B\u3002"
        },
        {
          id: "gc",
          term: "garbage collection",
          match: ["GC", "\u30AC\u30D9\u30FC\u30B8\u30B3\u30EC\u30AF\u30B7\u30E7\u30F3", "\u30AC\u30D9\u30B3\u30EC"],
          short: "\u4F7F\u308F\u308C\u306A\u304F\u306A\u3063\u305F\u30E1\u30E2\u30EA\u3092\u81EA\u52D5\u3067\u56DE\u53CE\u3059\u308B\u4ED5\u7D44\u307F\u3002",
          detail: "\u3069\u3053\u304B\u3089\u3082\u53C2\u7167\u3055\u308C\u306A\u304F\u306A\u3063\u305F\u30AA\u30D6\u30B8\u30A7\u30AF\u30C8\u3092\u51E6\u7406\u7CFB\u304C\u898B\u3064\u3051\u3066\u89E3\u653E\u3059\u308B\u3002\u56DE\u53CE\u4E2D\u306B\u4E00\u77AC\u6B62\u307E\u308B\u3053\u3068\u304C\u3042\u308A\u3001\u3053\u308C\u3092 stop-the-world \u3068\u547C\u3076\u3002"
        },
        {
          id: "immutable",
          term: "immutable",
          match: ["\u30A4\u30DF\u30E5\u30FC\u30BF\u30D6\u30EB", "\u4E0D\u5909", "immutability"],
          short: "\u4F5C\u3063\u305F\u5F8C\u306B\u4E2D\u8EAB\u3092\u66F8\u304D\u63DB\u3048\u3089\u308C\u306A\u3044\u30C7\u30FC\u30BF\u3002",
          detail: "\u5909\u66F4\u3059\u308B\u3068\u304D\u306F\u65B0\u3057\u3044\u5024\u3092\u4F5C\u308A\u76F4\u3059\u3002\u8AB0\u304B\u306B\u52DD\u624B\u306B\u66F8\u304D\u63DB\u3048\u3089\u308C\u308B\u5FC3\u914D\u304C\u306A\u3044\u306E\u3067\u3001\u5DEE\u5206\u691C\u77E5\u3084\u4E26\u884C\u51E6\u7406\u304C\u697D\u306B\u306A\u308B\u3002"
        },
        {
          id: "dependency-injection",
          term: "dependency injection",
          match: ["DI", "\u4F9D\u5B58\u6027\u6CE8\u5165"],
          short: "\u4F7F\u3046\u90E8\u54C1\u3092\u81EA\u5206\u3067\u4F5C\u3089\u305A\u3001\u5916\u304B\u3089\u6E21\u3057\u3066\u3082\u3089\u3046\u8A2D\u8A08\u3002",
          detail: "\u30C6\u30B9\u30C8\u6642\u306B\u672C\u7269\u306EDB\u306E\u4EE3\u308F\u308A\u306B\u507D\u7269\u3092\u6E21\u3059\u3001\u3068\u3044\u3063\u305F\u5DEE\u3057\u66FF\u3048\u304C\u3067\u304D\u308B\u3002\u6E21\u3059\u5074\u304C\u5897\u3048\u308B\u3076\u3093\u521D\u671F\u306E\u898B\u901A\u3057\u306F\u60AA\u304F\u306A\u308B\u3002"
        },
        {
          id: "middleware",
          term: "middleware",
          match: ["\u30DF\u30C9\u30EB\u30A6\u30A7\u30A2"],
          short: "\u30EA\u30AF\u30A8\u30B9\u30C8\u3068\u672C\u51E6\u7406\u306E\u9593\u306B\u631F\u307E\u308B\u5171\u901A\u51E6\u7406\u3002",
          detail: "\u8A8D\u8A3C\u30FB\u30ED\u30B0\u30FB\u30A8\u30E9\u30FC\u51E6\u7406\u306A\u3069\u3001\u3069\u306E\u30A8\u30F3\u30C9\u30DD\u30A4\u30F3\u30C8\u3067\u3082\u5FC5\u8981\u306A\u51E6\u7406\u3092\u307E\u3068\u3081\u3066\u5DEE\u3057\u8FBC\u3080\u5C64\u3002\u9806\u756A\u306B\u901A\u904E\u3057\u3066\u3044\u304F\u3002"
        },
        {
          id: "polyfill",
          term: "polyfill",
          match: ["\u30DD\u30EA\u30D5\u30A3\u30EB"],
          short: "\u53E4\u3044\u74B0\u5883\u306B\u65B0\u3057\u3044\u6A5F\u80FD\u3092\u5F8C\u4ED8\u3051\u3059\u308B\u30B3\u30FC\u30C9\u3002",
          detail: "\u30D6\u30E9\u30A6\u30B6\u304C\u672A\u5BFE\u5FDC\u306E API \u3092\u3001\u65E2\u5B58\u306E\u6A5F\u80FD\u3060\u3051\u3067\u540C\u3058\u52D5\u304D\u306B\u518D\u73FE\u3059\u308B\u3002\u5BFE\u5FDC\u6E08\u307F\u306E\u74B0\u5883\u3067\u306F\u8AAD\u307F\u8FBC\u307E\u308C\u306A\u3044\u3088\u3046\u306B\u3059\u308B\u306E\u304C\u666E\u901A\u3002"
        },
        {
          id: "hoisting",
          term: "hoisting",
          match: ["\u5DFB\u304D\u4E0A\u3052", "\u30DB\u30A4\u30B9\u30C6\u30A3\u30F3\u30B0"],
          short: "\u5BA3\u8A00\u304C\u30B9\u30B3\u30FC\u30D7\u306E\u5148\u982D\u306B\u6301\u3061\u4E0A\u3052\u3089\u308C\u308B\u6319\u52D5\u3002",
          detail: "var \u3068\u95A2\u6570\u5BA3\u8A00\u306F\u5B9A\u7FA9\u524D\u306B\u53C2\u7167\u3067\u304D\u3066\u3057\u307E\u3046\u3002let / const \u3082\u5DFB\u304D\u4E0A\u3052\u3089\u308C\u308B\u304C\u3001\u5BA3\u8A00\u524D\u306E\u30A2\u30AF\u30BB\u30B9\u306F\u30A8\u30E9\u30FC\u306B\u306A\u308B\uFF08TDZ\uFF09\u3002",
          langs: ["javascript", "typescript", "javascriptreact", "typescriptreact"]
        },
        {
          id: "use-state",
          term: "useState",
          match: ["\u30E6\u30FC\u30BA\u30B9\u30C6\u30FC\u30C8"],
          short: "React \u3067\u300C\u5909\u308F\u308B\u5024\u300D\u3092\u6301\u3064\u305F\u3081\u306E\u30D5\u30C3\u30AF\u3002",
          detail: "\u73FE\u5728\u306E\u5024\u3068\u66F4\u65B0\u95A2\u6570\u306E\u30DA\u30A2\u3092\u8FD4\u3059\u3002\u66F4\u65B0\u95A2\u6570\u3092\u547C\u3076\u3068\u305D\u306E\u30B3\u30F3\u30DD\u30FC\u30CD\u30F3\u30C8\u304C\u518D\u63CF\u753B\u3055\u308C\u308B\u3002",
          example: "const [count, setCount] = useState(0);",
          link: "https://ja.react.dev/reference/react/useState",
          langs: ["javascript", "typescript", "javascriptreact", "typescriptreact"]
        },
        {
          id: "use-effect",
          term: "useEffect",
          short: "React \u3067\u63CF\u753B\u306E\u3042\u3068\u306B\u526F\u4F5C\u7528\u3092\u8D70\u3089\u305B\u308B\u30D5\u30C3\u30AF\u3002",
          detail: "\u901A\u4FE1\u30FB\u8CFC\u8AAD\u30FBDOM \u64CD\u4F5C\u306A\u3069\u3001\u63CF\u753B\u305D\u306E\u3082\u306E\u3067\u306F\u306A\u3044\u51E6\u7406\u3092\u7F6E\u304F\u3002\u7B2C 2 \u5F15\u6570\u306E\u4F9D\u5B58\u914D\u5217\u306B\u5165\u308C\u305F\u5024\u304C\u5909\u308F\u3063\u305F\u3068\u304D\u3060\u3051\u518D\u5B9F\u884C\u3055\u308C\u308B\u3002",
          link: "https://ja.react.dev/reference/react/useEffect",
          langs: ["javascript", "typescript", "javascriptreact", "typescriptreact"]
        },
        {
          id: "promise",
          term: "Promise",
          match: ["\u30D7\u30ED\u30DF\u30B9"],
          short: "\u300C\u3042\u3068\u3067\u7D50\u679C\u304C\u5165\u308B\u7BB1\u300D\u3092\u8868\u3059\u30AA\u30D6\u30B8\u30A7\u30AF\u30C8\u3002",
          detail: "pending \u2192 fulfilled / rejected \u3068\u4E00\u5EA6\u3060\u3051\u72B6\u614B\u304C\u5909\u308F\u308B\u3002await \u3067\u4E2D\u8EAB\u3092\u53D6\u308A\u51FA\u3059\u304B\u3001.then / .catch \u3067\u3064\u306A\u3050\u3002",
          langs: ["javascript", "typescript", "javascriptreact", "typescriptreact"]
        },
        {
          id: "generic",
          term: "generics",
          match: ["\u30B8\u30A7\u30CD\u30EA\u30AF\u30B9", "generic", "\u578B\u5F15\u6570"],
          short: "\u578B\u3092\u5F8C\u304B\u3089\u5DEE\u3057\u8FBC\u3081\u308B\u3088\u3046\u306B\u3059\u308B\u4ED5\u7D44\u307F\u3002",
          detail: "Array<T> \u306E T \u306E\u3088\u3046\u306B\u3001\u4F7F\u3046\u5074\u304C\u578B\u3092\u6C7A\u3081\u308B\u3002any \u3068\u9055\u3063\u3066\u4E2D\u8EAB\u306E\u578B\u304C\u6700\u5F8C\u307E\u3067\u8FFD\u8DE1\u3055\u308C\u308B\u3002"
        },
        {
          id: "type-guard",
          term: "type guard",
          match: ["\u578B\u30AC\u30FC\u30C9"],
          short: "\u5B9F\u884C\u6642\u306E\u30C1\u30A7\u30C3\u30AF\u3067\u578B\u3092\u7D5E\u308A\u8FBC\u3080\u66F8\u304D\u65B9\u3002",
          detail: "typeof \u3084 in\u3001`x is Foo` \u3092\u8FD4\u3059\u95A2\u6570\u3092\u4F7F\u3046\u3068\u3001\u305D\u306E\u5206\u5C90\u306E\u4E2D\u3067\u30B3\u30F3\u30D1\u30A4\u30E9\u304C\u578B\u3092\u72ED\u3081\u3066\u304F\u308C\u308B\u3002",
          langs: ["typescript", "typescriptreact"]
        },
        {
          id: "orm",
          term: "ORM",
          match: ["\u30AA\u30FC\u30A2\u30FC\u30EB\u30A8\u30E0", "object relational mapping"],
          short: "DB \u306E\u30C6\u30FC\u30D6\u30EB\u3092\u30B3\u30FC\u30C9\u306E\u30AA\u30D6\u30B8\u30A7\u30AF\u30C8\u3068\u3057\u3066\u6271\u3046\u9053\u5177\u3002",
          detail: "SQL \u3092\u76F4\u63A5\u66F8\u304B\u305A\u306B\u30C7\u30FC\u30BF\u3092\u8AAD\u307F\u66F8\u304D\u3067\u304D\u308B\u3002\u624B\u8EFD\u306A\u4EE3\u308F\u308A\u306B\u3001\u751F\u6210\u3055\u308C\u308B SQL \u304C\u91CD\u304F\u306A\u308A\u304C\u3061\u306A\u306E\u3067\u8981\u6CE8\u610F\u3002"
        },
        {
          id: "n-plus-one",
          term: "N+1 problem",
          match: ["N+1", "\u30A8\u30CC\u30D7\u30E9\u30B9\u30EF\u30F3"],
          short: "\u4E00\u89A7\u3092\u51FA\u3059\u305F\u3073\u306B\u4EF6\u6570\u3076\u3093\u8FFD\u52A0\u30AF\u30A8\u30EA\u304C\u98DB\u3076\u6027\u80FD\u554F\u984C\u3002",
          detail: "\u4E00\u89A7 1 \u56DE + \u5404\u884C 1 \u56DE\u305A\u3064\u3067 N+1 \u56DE\u3002ORM \u3067\u6C17\u3065\u304B\u305A\u306B\u3084\u308A\u304C\u3061\u3002JOIN \u3084\u4E00\u62EC\u30ED\u30FC\u30C9\u3067\u307E\u3068\u3081\u3066\u89E3\u6C7A\u3059\u308B\u3002"
        },
        {
          id: "idempotency-key",
          term: "idempotency key",
          match: ["\u51AA\u7B49\u30AD\u30FC"],
          short: "\u540C\u3058\u30EA\u30AF\u30A8\u30B9\u30C8\u306E\u4E8C\u91CD\u5B9F\u884C\u3092\u9632\u3050\u305F\u3081\u306E\u8B58\u5225\u5B50\u3002",
          detail: "\u6C7A\u6E08\u306A\u3069\u3067\u3001\u901A\u4FE1\u30A8\u30E9\u30FC\u5F8C\u306E\u518D\u9001\u304C\u4E8C\u91CD\u8AB2\u91D1\u306B\u306A\u3089\u306A\u3044\u3088\u3046\u306B\u3059\u308B\u3002\u30B5\u30FC\u30D0\u5074\u306F\u540C\u3058\u30AD\u30FC\u3092\u898B\u305F\u3089\u524D\u56DE\u306E\u7D50\u679C\u3092\u305D\u306E\u307E\u307E\u8FD4\u3059\u3002"
        },
        {
          id: "cors",
          term: "CORS",
          match: ["\u30AA\u30EA\u30B8\u30F3\u9593\u30EA\u30BD\u30FC\u30B9\u5171\u6709", "cross origin resource sharing"],
          short: "\u5225\u30C9\u30E1\u30A4\u30F3\u3078\u306E\u30D6\u30E9\u30A6\u30B6\u304B\u3089\u306E\u901A\u4FE1\u3092\u8A31\u53EF\u3059\u308B\u4ED5\u7D44\u307F\u3002",
          detail: "\u30B5\u30FC\u30D0\u304C Access-Control-Allow-Origin \u306A\u3069\u306E\u30D8\u30C3\u30C0\u3067\u660E\u793A\u7684\u306B\u8A31\u53EF\u3059\u308B\u3002\u30D6\u30E9\u30A6\u30B6\u5074\u3060\u3051\u3067\u306F\u56DE\u907F\u3067\u304D\u306A\u3044\u3002"
        },
        {
          id: "jwt",
          term: "JWT",
          match: ["json web token", "\u30B8\u30E7\u30C3\u30C8"],
          short: "\u7F72\u540D\u3064\u304D\u3067\u4E2D\u8EAB\u3092\u81EA\u5206\u3067\u691C\u8A3C\u3067\u304D\u308B\u30C8\u30FC\u30AF\u30F3\u3002",
          detail: "\u30D8\u30C3\u30C0\u30FB\u30DA\u30A4\u30ED\u30FC\u30C9\u30FB\u7F72\u540D\u306E 3 \u3064\u3092 . \u3067\u3064\u306A\u3044\u3060\u6587\u5B57\u5217\u3002\u6697\u53F7\u5316\u3067\u306F\u306A\u3044\u306E\u3067\u3001\u30DA\u30A4\u30ED\u30FC\u30C9\u306F\u8AB0\u3067\u3082\u8AAD\u3081\u308B\u70B9\u306B\u6CE8\u610F\u3002"
        },
        {
          id: "migration",
          term: "migration",
          match: ["\u30DE\u30A4\u30B0\u30EC\u30FC\u30B7\u30E7\u30F3", "\u30DE\u30A4\u30B0\u30EC"],
          short: "DB \u306E\u30B9\u30AD\u30FC\u30DE\u5909\u66F4\u3092\u624B\u9806\u3068\u3057\u3066\u8A18\u9332\u3057\u305F\u30D5\u30A1\u30A4\u30EB\u3002",
          detail: "\u9069\u7528\u9806\u306B\u756A\u53F7\u304C\u632F\u3089\u308C\u3001\u3069\u3053\u307E\u3067\u9069\u7528\u6E08\u307F\u304B\u3092 DB \u5074\u304C\u899A\u3048\u3066\u3044\u308B\u3002\u672C\u756A\u3067\u306F\u623B\u305B\u306A\u3044\u5909\u66F4\u304C\u591A\u3044\u306E\u3067\u3001\u524D\u9032\u306E\u307F\u3067\u8A2D\u8A08\u3059\u308B\u306E\u304C\u5B89\u5168\u3002"
        },
        {
          id: "debounce",
          term: "debounce",
          match: ["\u30C7\u30D0\u30A6\u30F3\u30B9"],
          short: "\u9023\u7D9A\u3057\u305F\u547C\u3073\u51FA\u3057\u3092\u3001\u6B62\u307E\u3063\u3066\u304B\u3089 1 \u56DE\u306B\u307E\u3068\u3081\u308B\u3002",
          detail: "\u5165\u529B\u6B04\u306E\u30A4\u30F3\u30AF\u30EA\u30E1\u30F3\u30BF\u30EB\u691C\u7D22\u3067\u3088\u304F\u4F7F\u3046\u3002\u4E00\u5B9A\u9593\u9694\u3054\u3068\u306B 1 \u56DE\u306B\u3059\u308B throttle \u3068\u306F\u5225\u7269\u3002"
        },
        {
          id: "throttle",
          term: "throttle",
          match: ["\u30B9\u30ED\u30C3\u30C8\u30EB", "\u30B9\u30ED\u30C3\u30C8\u30EA\u30F3\u30B0", "throttling"],
          short: "\u547C\u3073\u51FA\u3057\u306E\u983B\u5EA6\u3092\u4E00\u5B9A\u9593\u9694\u307E\u3067\u306B\u5236\u9650\u3059\u308B\u3002",
          detail: "\u30B9\u30AF\u30ED\u30FC\u30EB\u3084\u30EA\u30B5\u30A4\u30BA\u306E\u3088\u3046\u306B\u3001\u9CF4\u308A\u7D9A\u3051\u308B\u30A4\u30D9\u30F3\u30C8\u3092\u9593\u5F15\u304F\u306E\u306B\u4F7F\u3046\u3002\u6700\u5F8C\u306E 1 \u56DE\u3060\u3051\u306B\u3057\u305F\u3044\u306A\u3089 debounce\u3002"
        },
        {
          id: "exponential-backoff",
          term: "exponential backoff",
          match: ["\u6307\u6570\u30D0\u30C3\u30AF\u30AA\u30D5", "backoff"],
          short: "\u30EA\u30C8\u30E9\u30A4\u9593\u9694\u3092 1\u79D2, 2\u79D2, 4\u79D2\u2026\u3068\u4F38\u3070\u3057\u3066\u3044\u304F\u65B9\u5F0F\u3002",
          detail: "\u843D\u3061\u3066\u3044\u308B\u30B5\u30FC\u30D0\u306B\u4E00\u6589\u306B\u518D\u63A5\u7D9A\u3057\u3066\u8FFD\u3044\u6253\u3061\u3092\u304B\u3051\u308B\u306E\u3092\u9632\u3050\u3002\u5B9F\u969B\u306B\u306F\u30E9\u30F3\u30C0\u30E0\u306A\u63FA\u3089\u304E\uFF08jitter\uFF09\u3082\u8DB3\u3059\u3002"
        },
        {
          id: "single-source-of-truth",
          term: "single source of truth",
          match: ["SSOT", "\u4FE1\u983C\u3067\u304D\u308B\u552F\u4E00\u306E\u60C5\u5831\u6E90"],
          short: "\u540C\u3058\u60C5\u5831\u306E\u6B63\u672C\u3092 1 \u7B87\u6240\u3060\u3051\u306B\u6301\u3064\u8A2D\u8A08\u65B9\u91DD\u3002",
          detail: "\u540C\u3058\u5024\u3092\u3042\u3061\u3053\u3061\u306B\u30B3\u30D4\u30FC\u3059\u308B\u3068\u5FC5\u305A\u30BA\u30EC\u308B\u3002\u30B3\u30D4\u30FC\u3067\u306F\u306A\u304F\u53C2\u7167\u3055\u305B\u308B\u304B\u30011 \u7B87\u6240\u304B\u3089\u81EA\u52D5\u751F\u6210\u3059\u308B\u3002"
        },
        {
          id: "feature-flag",
          term: "feature flag",
          match: ["\u30D5\u30A3\u30FC\u30C1\u30E3\u30FC\u30D5\u30E9\u30B0", "feature toggle", "\u6A5F\u80FD\u30D5\u30E9\u30B0"],
          short: "\u30B3\u30FC\u30C9\u3092\u51FA\u3057\u305F\u307E\u307E\u6A5F\u80FD\u306E\u30AA\u30F3/\u30AA\u30D5\u3092\u5207\u308A\u66FF\u3048\u308B\u4ED5\u7D44\u307F\u3002",
          detail: "\u30C7\u30D7\u30ED\u30A4\u3068\u516C\u958B\u3092\u5206\u96E2\u3067\u304D\u308B\u3002\u6D88\u3057\u5FD8\u308C\u305F\u30D5\u30E9\u30B0\u304C\u5206\u5C90\u3068\u3057\u3066\u6B8B\u308A\u7D9A\u3051\u308B\u306E\u3067\u3001\u5BFF\u547D\u3092\u6C7A\u3081\u3066\u904B\u7528\u3059\u308B\u3002"
        }
      ];
    }
  });

  // ../core/dist/normalize.js
  var require_normalize = __commonJS({
    "../core/dist/normalize.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.normalize = normalize;
      exports.tighten = tighten;
      exports.tokenize = tokenize;
      function normalize(input) {
        return input.normalize("NFKC").replace(/([a-z0-9])([A-Z])/g, "$1 $2").replace(/([A-Z]+)([A-Z][a-z])/g, "$1 $2").replace(/[_\-./:]+/g, " ").toLowerCase().replace(/\s+/g, " ").trim();
      }
      function tighten(normalized) {
        return normalized.replace(/\s+/g, "");
      }
      var TOKEN_RE = /[A-Za-z_$][A-Za-z0-9_$]*|[ァ-ヶーｦ-ﾟ]+/gu;
      function tokenize(text) {
        const tokens = [];
        for (const m of text.matchAll(TOKEN_RE)) {
          tokens.push({ text: m[0], start: m.index, end: m.index + m[0].length });
        }
        return tokens;
      }
    }
  });

  // ../core/dist/dictionary.js
  var require_dictionary = __commonJS({
    "../core/dist/dictionary.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.Dictionary = void 0;
      var normalize_1 = require_normalize();
      var MAX_PHRASE_TOKENS = 4;
      var JOINER_RE = /^[\s\-_.]*$/;
      var Dictionary2 = class {
        /** 正規化キー -> エントリ群（同綴りで言語違いがありうるので配列）。 */
        index = /* @__PURE__ */ new Map();
        constructor(entries) {
          for (const entry of entries) {
            for (const surface of [entry.term, ...entry.match ?? []]) {
              const norm = (0, normalize_1.normalize)(surface);
              if (!norm)
                continue;
              this.add(norm, entry);
              const tight = (0, normalize_1.tighten)(norm);
              if (tight !== norm)
                this.add(tight, entry);
            }
          }
        }
        add(key, entry) {
          const bucket = this.index.get(key);
          if (bucket) {
            if (!bucket.includes(entry))
              bucket.push(entry);
          } else {
            this.index.set(key, [entry]);
          }
        }
        /** 単一の語句を引く。ホバー位置が分かっていない場合はこちら。 */
        lookup(surface, options = {}) {
          const norm = (0, normalize_1.normalize)(surface);
          return this.pick(norm, options) ?? this.pick((0, normalize_1.tighten)(norm), options);
        }
        pick(key, { lang }) {
          const bucket = this.index.get(key);
          if (!bucket)
            return void 0;
          if (lang) {
            const scoped = bucket.find((e) => e.langs?.includes(lang));
            if (scoped)
              return scoped;
          }
          return bucket.find((e) => !e.langs) ?? bucket[0];
        }
        /**
         * `text` の `offset` 位置にある語を引く。複合語を優先し、長い一致から試す。
         * VS Code のホバーもブラウザのホバーもこの 1 関数に集約する。
         */
        findAt(text, offset, options = {}) {
          const tokens = (0, normalize_1.tokenize)(text);
          const hit = tokens.findIndex((t) => offset >= t.start && offset <= t.end);
          if (hit === -1)
            return void 0;
          for (let len = MAX_PHRASE_TOKENS; len >= 1; len--) {
            for (let start = hit - len + 1; start <= hit; start++) {
              if (start < 0 || start + len > tokens.length)
                continue;
              const window2 = tokens.slice(start, start + len);
              if (!isContiguous(text, window2))
                continue;
              const phrase = window2.map((t) => t.text).join(" ");
              const entry = this.lookup(phrase, options);
              if (entry) {
                return { entry, start: window2[0].start, end: window2[window2.length - 1].end };
              }
            }
          }
          return void 0;
        }
      };
      exports.Dictionary = Dictionary2;
      function isContiguous(text, window2) {
        for (let i = 1; i < window2.length; i++) {
          if (!JOINER_RE.test(text.slice(window2[i - 1].end, window2[i].start)))
            return false;
        }
        return true;
      }
    }
  });

  // ../core/dist/render.js
  var require_render = __commonJS({
    "../core/dist/render.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.toMarkdown = toMarkdown;
      function toMarkdown(entry) {
        const lines = [`**${entry.term}** \u2014 ${entry.short}`];
        if (entry.detail)
          lines.push("", entry.detail);
        if (entry.example)
          lines.push("", "```", entry.example, "```");
        if (entry.link)
          lines.push("", `[\u8A73\u3057\u304F](${entry.link})`);
        return lines.join("\n");
      }
    }
  });

  // ../core/dist/index.js
  var require_dist = __commonJS({
    "../core/dist/index.js"(exports) {
      "use strict";
      var __importDefault = exports && exports.__importDefault || function(mod) {
        return mod && mod.__esModule ? mod : { "default": mod };
      };
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.builtinDictionary = exports.builtinTerms = exports.toMarkdown = exports.tokenize = exports.tighten = exports.normalize = exports.Dictionary = void 0;
      var terms_json_1 = __importDefault(require_terms());
      var dictionary_1 = require_dictionary();
      var dictionary_2 = require_dictionary();
      Object.defineProperty(exports, "Dictionary", { enumerable: true, get: function() {
        return dictionary_2.Dictionary;
      } });
      var normalize_1 = require_normalize();
      Object.defineProperty(exports, "normalize", { enumerable: true, get: function() {
        return normalize_1.normalize;
      } });
      Object.defineProperty(exports, "tighten", { enumerable: true, get: function() {
        return normalize_1.tighten;
      } });
      Object.defineProperty(exports, "tokenize", { enumerable: true, get: function() {
        return normalize_1.tokenize;
      } });
      var render_1 = require_render();
      Object.defineProperty(exports, "toMarkdown", { enumerable: true, get: function() {
        return render_1.toMarkdown;
      } });
      exports.builtinTerms = terms_json_1.default;
      exports.builtinDictionary = new dictionary_1.Dictionary(exports.builtinTerms);
    }
  });

  // src/content.ts
  var import_core = __toESM(require_dist());
  var dictionary = new import_core.Dictionary(import_core.builtinTerms);
  var HOVER_DELAY_MS = 250;
  var tooltip = createTooltip();
  var hoverTimer;
  var currentId;
  document.addEventListener("mousemove", (event) => {
    window.clearTimeout(hoverTimer);
    hoverTimer = window.setTimeout(() => handleHover(event), HOVER_DELAY_MS);
  });
  document.addEventListener("scroll", hide, { passive: true, capture: true });
  window.addEventListener("blur", hide);
  function handleHover(event) {
    const caret = caretFromPoint(event.clientX, event.clientY);
    if (!caret || caret.node.nodeType !== Node.TEXT_NODE) return hide();
    const text = caret.node.textContent ?? "";
    const hit = dictionary.findAt(text, caret.offset);
    if (!hit) return hide();
    if (hit.entry.id === currentId && tooltip.host.isConnected) return;
    currentId = hit.entry.id;
    render(hit);
    position(caret.node, hit);
    tooltip.host.style.display = "block";
  }
  function hide() {
    currentId = void 0;
    tooltip.host.style.display = "none";
  }
  function position(node, hit) {
    const range = document.createRange();
    range.setStart(node, hit.start);
    range.setEnd(node, hit.end);
    const word = range.getBoundingClientRect();
    tooltip.host.style.left = `${Math.max(8, Math.min(word.left, window.innerWidth - 360))}px`;
    tooltip.host.style.top = `${word.bottom + 6}px`;
    const box = tooltip.panel.getBoundingClientRect();
    if (word.bottom + 6 + box.height > window.innerHeight) {
      tooltip.host.style.top = `${Math.max(8, word.top - box.height - 6)}px`;
    }
  }
  function render({ entry }) {
    const { panel } = tooltip;
    panel.replaceChildren();
    const head = document.createElement("div");
    head.className = "tw-head";
    head.textContent = entry.term;
    panel.append(head);
    const short = document.createElement("div");
    short.className = "tw-short";
    short.textContent = entry.short;
    panel.append(short);
    if (entry.detail) {
      const detail = document.createElement("div");
      detail.className = "tw-detail";
      detail.textContent = entry.detail;
      panel.append(detail);
    }
    if (entry.example) {
      const example = document.createElement("pre");
      example.className = "tw-example";
      example.textContent = entry.example;
      panel.append(example);
    }
    if (entry.link) {
      const link = document.createElement("a");
      link.className = "tw-link";
      link.href = entry.link;
      link.target = "_blank";
      link.rel = "noreferrer noopener";
      link.textContent = "\u8A73\u3057\u304F";
      panel.append(link);
    }
  }
  function createTooltip() {
    const host = document.createElement("div");
    host.style.cssText = "position:fixed;z-index:2147483647;display:none;";
    const root = host.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent = `
    .tw-panel {
      max-width: 340px; padding: 10px 12px; border-radius: 8px;
      background: #1f2430; color: #e6e6e6; border: 1px solid #3a4152;
      box-shadow: 0 6px 20px rgba(0,0,0,.35);
      font: 13px/1.6 -apple-system, "Hiragino Sans", "Noto Sans JP", sans-serif;
    }
    .tw-head { font-weight: 700; margin-bottom: 2px; }
    .tw-short { color: #f2f2f2; }
    .tw-detail { margin-top: 6px; color: #b9c0cf; }
    .tw-example {
      margin: 8px 0 0; padding: 6px 8px; border-radius: 6px; overflow-x: auto;
      background: #12161f; font: 12px/1.5 ui-monospace, SFMono-Regular, monospace;
    }
    .tw-link { display: inline-block; margin-top: 8px; color: #7fb2ff; }
  `;
    const panel = document.createElement("div");
    panel.className = "tw-panel";
    root.append(style, panel);
    document.documentElement.append(host);
    return { host, panel };
  }
  function caretFromPoint(x, y) {
    const doc = document;
    const range = doc.caretRangeFromPoint?.(x, y);
    if (range) return { node: range.startContainer, offset: range.startOffset };
    const pos = doc.caretPositionFromPoint?.(x, y);
    if (pos) return { node: pos.offsetNode, offset: pos.offset };
    return void 0;
  }
})();
